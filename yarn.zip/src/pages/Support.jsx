import React, {useState} from 'react';

const Support = () => {

  return (
   <div className='w-full'>

    </div>
  )
}

export default Support
