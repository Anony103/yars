import React from 'react'

const Productions = () => {
  return (
    <div>
      <div>
        <img src="" alt="" />
      </div>
      <h1></h1>
      <p>₦</p>
    </div>
  )
}

export default Productions
